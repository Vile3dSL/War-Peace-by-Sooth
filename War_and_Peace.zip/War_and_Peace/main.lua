local api = require("api")

local war_timers = {
    name = "WarTimers",
    version = "1.1-SOOTH-EDITION",
    author = "Sooth"
}

------------------------------------------------------
-- CONFIGURATION
------------------------------------------------------
local WINDOW_WIDTH = 390
local ROW_HEIGHT = 28
local BG_COLOR = {0, 0, 0, 0.6} 

-- ZONE LISTS
local ZONES = {
    NUIA = {
        {id = 20, name = "Cinderstone Moor"},
        {id = 22, name = "Halcyona"},
        {id = 26, name = "Hellswamp"},
        {id = 27, name = "Sanddeep"},
        {id = 19, name = "Karkasse Ridgelands"}
    },
    HARANYA = {
        {id = 17, name = "Ynystere"},
        {id = 16, name = "Rookborne Basin"},
        {id = 14, name = "Windscour Savannah"},
        {id = 15, name = "Perinoor Ruins"},
        {id = 23, name = "Hasla"}
    },
    AURORIA = {
        {id = 61, name = "Diamond Shores"},
        {id = 57, name = "Golden Ruins"},
        {id = 103,name = "Whalesong Harbor"},
        {id = 56, name = "Sungold Fields"},
        {id = 54, name = "Exeloch"}
    }
}

------------------------------------------------------
-- VARIABLES
------------------------------------------------------
local window = nil
local content_frame = nil
local current_tab = "NUIA" 
local is_minimized = false
local row_widgets = {} 
local update_tick = 0 

local widgets = {
    btnNuia = nil,
    btnHara = nil,
    btnAuro = nil,
    btnMin = nil
}

------------------------------------------------------
-- UTILITY
------------------------------------------------------
local function GetTimeText(ms)
    if type(ms) ~= "number" or ms <= 0 then return "" end
    -- Handle Seconds vs Milliseconds
    if ms < 500000 then ms = ms * 1000 end 
    
    local s = math.floor(ms / 1000)
    local m = math.floor(s / 60)
    local h = math.floor(m / 60)
    s = s % 60
    m = m % 60
    
    if h > 0 then return string.format("%dh %02dm", h, m)
    else return string.format("%02dm %02ds", m, s) end
end

-- COLORS
local C_PEACE_BLUE = {0.4, 0.9, 1, 1} -- Light Blue (Peace)
local C_TENSION    = {1, 1, 0.4, 1}   -- Yellow (Tension/Danger Lvl 1)
local C_DANGER     = {1, 0.6, 0, 1}   -- Orange (Danger Lvl 2-4)
local C_DISPUTE    = {1, 0.4, 0, 1}   -- Dark Orange (Conflict/Dispute)
local C_RED        = {1, 0.2, 0.2, 1} -- Red (War/Hostile)
local C_GREY       = {0.6, 0.6, 0.6, 1} 
local C_EVENT_BLUE = {0.2, 0.6, 1, 1} -- Darker Blue (Events)

local function GetStateInfo(stateId, isNonPeace, zoneId)

    -------------------------------------------------
    -- 1. SPECIFIC EXCEPTIONS
    -------------------------------------------------
    -- Halcyona (ID 22): State 0 is Golden Plains Battle.
    if zoneId == 22 and stateId == 0 then
        return "Event Active", C_EVENT_BLUE
    end

    -------------------------------------------------
    -- 2. WAR & SIEGE (Highest Priority)
    -------------------------------------------------
    -- State 6 is always War (Red).
    if stateId == 6 then return "At War", C_RED end

    -- State 7 handling (Diamond Shores Peace):
    if stateId == 7 then
        return "Peace", C_PEACE_BLUE
    end

    -------------------------------------------------
    -- 3. MAINLAND LOGIC 
    -------------------------------------------------
    
    -- Conflict (5)
    if stateId == 5 then return "In Conflict", C_DISPUTE end

    -- Dispute (4)
    if stateId == 4 then return "Dispute", C_DISPUTE end

    -- Danger Levels (3, 2, 1) -> Orange
    if stateId == 3 then return "Danger Lvl 4", C_DANGER end
    if stateId == 2 then return "Danger Lvl 3", C_DANGER end
    if stateId == 1 then return "Danger Lvl 2", C_DANGER end

    -- Tension (0) -> Yellow
    if stateId == 0 then return "Tension (Danger Lvl 1)", C_TENSION end

    -------------------------------------------------
    -- 4. PEACE CHECK (Final Fallback)
    -------------------------------------------------
    if isNonPeace == false then 
        return "Peace", C_PEACE_BLUE 
    end
    
    return "State " .. tostring(stateId), C_GREY
end

------------------------------------------------------
-- UI LOGIC
------------------------------------------------------
local function CreateRow(index)
    local row = content_frame:CreateChildWidget("emptywidget", "row_"..index, 0, true)
    row:SetExtent(WINDOW_WIDTH - 20, ROW_HEIGHT)
    row:AddAnchor("TOPLEFT", content_frame, 10, (index - 1) * ROW_HEIGHT + 2)

    if index % 2 == 0 then
        local rowBg = row:CreateNinePartDrawable(TEXTURE_PATH.HUD, "background")
        rowBg:SetTextureInfo("bg_quest")
        rowBg:SetColor(1, 1, 1, 0.05)
        rowBg:AddAnchor("TOPLEFT", row, 0, 0)
        rowBg:AddAnchor("BOTTOMRIGHT", row, 0, 0)
    end

    local name = row:CreateChildWidget("label", "name_"..index, 0, true)
    name:SetExtent(180, ROW_HEIGHT)
    name:AddAnchor("LEFT", row, 5, 0)
    name.style:SetAlign(ALIGN.LEFT)
    name.style:SetShadow(true)
    name.style:SetFontSize(FONT_SIZE.MIDDLE)

    local status = row:CreateChildWidget("label", "status_"..index, 0, true)
    status:SetExtent(160, ROW_HEIGHT)
    status:AddAnchor("RIGHT", row, -5, 0)
    status.style:SetAlign(ALIGN.RIGHT)
    status.style:SetShadow(true)
    status.style:SetFontSize(FONT_SIZE.MIDDLE)

    return {widget=row, labelName=name, labelStatus=status}
end

local function UpdateTimers()
    if is_minimized or not window:IsVisible() then return end
    
    local zoneList = ZONES[current_tab]
    
    for i = 1, #zoneList do
        if not row_widgets[i] then row_widgets[i] = CreateRow(i) end
        local row = row_widgets[i]
        local zoneDef = zoneList[i]
        
        row.labelName:SetText(zoneDef.name)
        row.labelName.style:SetColor(1, 1, 1, 1)
        row.widget:Show(true)

        local success, result = pcall(function()
            return api.Zone:GetZoneStateInfoByZoneId(zoneDef.id)
        end)

        if success and result then
            local time = result.remainTime or 0
            
            -- CALCULATE STATE
            local sName, color = GetStateInfo(result.conflictState, result.nonPeaceState, zoneDef.id)
            
            local tText = GetTimeText(time)
            
            if time > 0 then
                row.labelStatus:SetText(sName .. " (" .. tText .. ")")
            else
                row.labelStatus:SetText(sName)
            end
            row.labelStatus.style:SetColor(color[1], color[2], color[3], color[4])
        else
            row.labelStatus:SetText("No Data")
            row.labelStatus.style:SetColor(0.5, 0.5, 0.5, 1)
        end
    end
    
    for i = #zoneList + 1, #row_widgets do
        if row_widgets[i] then row_widgets[i].widget:Show(false) end
    end
end

------------------------------------------------------
-- WINDOW MANAGEMENT
------------------------------------------------------
local function ResizeWindow()
    if is_minimized then
        window:SetExtent(WINDOW_WIDTH, 35)
        content_frame:Show(false)
        widgets.btnNuia:Show(false)
        widgets.btnHara:Show(false)
        widgets.btnAuro:Show(false)
        widgets.btnMin:SetText("+")
    else
        local listSize = #ZONES[current_tab]
        local newHeight = 85 + (listSize * ROW_HEIGHT)
        window:SetExtent(WINDOW_WIDTH, newHeight)
        content_frame:Show(true)
        widgets.btnNuia:Show(true)
        widgets.btnHara:Show(true)
        widgets.btnAuro:Show(true)
        widgets.btnMin:SetText("-")
    end
end

local function SwitchTab(tabName)
    current_tab = tabName
    ResizeWindow()
    UpdateTimers()
end

local function ToggleMinimize()
    is_minimized = not is_minimized
    ResizeWindow()
end

local function OnDragStart(self)
    if api.Input:IsShiftKeyDown() then
        self:StartMoving()
        api.Cursor:ClearCursor()
        api.Cursor:SetCursorImage(CURSOR_PATH.MOVE, 0, 0)
    end
end

local function OnDragStop(self)
    self:StopMovingOrSizing()
    api.Cursor:ClearCursor()
end

function war_timers.OnLoad()
    window = api.Interface:CreateEmptyWindow("WarTimersWin", "UIParent")
    window:SetExtent(WINDOW_WIDTH, 200)
    window:AddAnchor("CENTER", "UIParent", 0, 0)
    
    window:EnableDrag(true)
    window:SetHandler("OnDragStart", OnDragStart)
    window:SetHandler("OnDragStop", OnDragStop)

    local bg = window:CreateNinePartDrawable(TEXTURE_PATH.HUD, "background")
    bg:SetTextureInfo("bg_quest")
    bg:SetColor(BG_COLOR[1], BG_COLOR[2], BG_COLOR[3], BG_COLOR[4])
    bg:AddAnchor("TOPLEFT", window, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", window, 0, 0)

    -- MAIN TITLE "War & Peace by Sooth"
    local title = window:CreateChildWidget("label", "title", 0, true)
    title:SetExtent(WINDOW_WIDTH, 20)
    title:AddAnchor("TOP", window, 0, 8)
    title.style:SetAlign(ALIGN.CENTER)
    title.style:SetFontSize(FONT_SIZE.LARGE)
    title:SetText("War & Peace by Sooth")
    title.style:SetColor(1, 0.8, 0.4, 1)

    local btnMin = window:CreateChildWidget("button", "btnMin", 0, true)
    btnMin:SetText("-")
    btnMin:SetExtent(20, 20)
    btnMin:AddAnchor("TOPRIGHT", window, -5, 5)
    api.Interface:ApplyButtonSkin(btnMin, BUTTON_BASIC.DEFAULT)
    btnMin:SetHandler("OnClick", ToggleMinimize)
    widgets.btnMin = btnMin

    -- TABS
    local tabWidth = (WINDOW_WIDTH - 20) / 3
    
    local btnNuia = window:CreateChildWidget("button", "btnNuia", 0, true)
    btnNuia:SetText("Nuia") 
    btnNuia:SetExtent(tabWidth, 30)
    btnNuia:AddAnchor("TOPLEFT", window, 5, 40)
    api.Interface:ApplyButtonSkin(btnNuia, BUTTON_BASIC.DEFAULT)
    btnNuia:SetHandler("OnClick", function() SwitchTab("NUIA") end)
    widgets.btnNuia = btnNuia
    
    local btnHara = window:CreateChildWidget("button", "btnHara", 0, true)
    btnHara:SetText("Haranya")
    btnHara:SetExtent(tabWidth, 30)
    btnHara:AddAnchor("TOPLEFT", btnNuia, "TOPRIGHT", 5, 0)
    api.Interface:ApplyButtonSkin(btnHara, BUTTON_BASIC.DEFAULT)
    btnHara:SetHandler("OnClick", function() SwitchTab("HARANYA") end)
    widgets.btnHara = btnHara

    local btnAuro = window:CreateChildWidget("button", "btnAuro", 0, true)
    btnAuro:SetText("Auroria")
    btnAuro:SetExtent(tabWidth, 30)
    btnAuro:AddAnchor("TOPLEFT", btnHara, "TOPRIGHT", 5, 0)
    api.Interface:ApplyButtonSkin(btnAuro, BUTTON_BASIC.DEFAULT)
    btnAuro:SetHandler("OnClick", function() SwitchTab("AURORIA") end)
    widgets.btnAuro = btnAuro

    content_frame = window:CreateChildWidget("emptywidget", "content", 0, true)
    content_frame:AddAnchor("TOPLEFT", window, 0, 80)
    content_frame:AddAnchor("BOTTOMRIGHT", window, 0, 0)

    -- SAFE LOOP
    api.On("UPDATE", function(dt)
        update_tick = update_tick + dt
        if update_tick > 1000 then
            UpdateTimers()
            update_tick = 0
        end
    end)

    window:Show(true)
    SwitchTab("NUIA")
end

function war_timers.OnUnload()
    if window then window:Show(false) end
end

return war_timers
local api = require("api")

local war_timers = {
    name = "WarTimers",
    version = "1.0"
}

------------------------------------------------------
-- CONFIGURATION
------------------------------------------------------
local WINDOW_WIDTH = 280
local ROW_HEIGHT = 20
local BG_COLOR = {0, 0, 0, 0.6} -- R, G, B, Alpha (0.6 is semi-transparent)

-- ZONE IDS (These are the specific numbers the game uses for zones)
-- If a zone shows "Unknown", the number here needs to be fixed.
local ZONES = {
    NUIA = {
        {id = 19, name = "Cinderstone"},
        {id = 21, name = "Halcyona"},
        {id = 22, name = "Hellswamp"},
        {id = 23, name = "Sanddeep"},
        {id = 24, name = "Karkasse"},
        {id = 15, name = "Marianople"} 
    },
    HARANYA = {
        {id = 18, name = "Ynystere"},
        {id = 20, name = "Rookborne"},
        {id = 25, name = "Windscour"},
        {id = 26, name = "Perinoor"},
        {id = 27, name = "Hasla"},
        {id = 16, name = "Austera"}
    }
}

------------------------------------------------------
-- VARIABLES
------------------------------------------------------
local window = nil
local content_frame = nil
local current_tab = "NUIA" 
local is_minimized = false
local row_widgets = {} 
local last_update_time = 0

------------------------------------------------------
-- HELPER FUNCTIONS
------------------------------------------------------
local function GetTimeText(ms)
    if not ms or ms <= 0 then return "" end
    local s = math.floor(ms / 1000)
    local m = math.floor(s / 60)
    local h = math.floor(m / 60)
    
    s = s % 60
    m = m % 60
    
    if h > 0 then return string.format("%dh %02dm", h, m) end
    return string.format("%02dm %02ds", m, s)
end

local function GetStateColor(stateId)
    -- 1=Peace, 2=Conflict, 3=War, 4=Siege (These vary by server version)
    if stateId == 1 then return {0.2, 1, 0.2, 1} end -- Green
    if stateId == 2 then return {1, 0.6, 0, 1} end   -- Orange
    if stateId == 3 then return {1, 0.2, 0.2, 1} end -- Red
    return {0.8, 0.8, 0.8, 1} -- White/Grey
end

local function GetStateName(stateId)
    if stateId == 1 then return "Peace" end
    if stateId == 2 then return "Conflict" end
    if stateId == 3 then return "War" end
    if stateId == 4 then return "Siege" end
    return "Normal"
end

------------------------------------------------------
-- UI LOGIC
------------------------------------------------------
local function CreateRow(index)
    local row = content_frame:CreateChildWidget("emptywidget", "row_"..index, 0, true)
    row:SetExtent(WINDOW_WIDTH - 20, ROW_HEIGHT)
    row:AddAnchor("TOPLEFT", content_frame, 10, (index - 1) * ROW_HEIGHT + 5)

    local name = row:CreateChildWidget("label", "name", 0, true)
    name:SetExtent(100, ROW_HEIGHT)
    name:AddAnchor("LEFT", row, 0, 0)
    name.style:SetAlign(ALIGN.LEFT)
    name.style:SetShadow(true)

    local status = row:CreateChildWidget("label", "status", 0, true)
    status:SetExtent(140, ROW_HEIGHT)
    status:AddAnchor("RIGHT", row, 0, 0)
    status.style:SetAlign(ALIGN.RIGHT)
    status.style:SetShadow(true)

    return {widget=row, labelName=name, labelStatus=status}
end

local function UpdateTimers()
    if is_minimized then return end
    
    local zoneList = ZONES[current_tab]
    
    for i = 1, #zoneList do
        -- Create row if it doesn't exist yet
        if not row_widgets[i] then
            row_widgets[i] = CreateRow(i)
        end
        
        local row = row_widgets[i]
        local zoneDef = zoneList[i]
        
        -- Get Data from Game
        local zoneState = api.Zone:GetZoneState(zoneDef.id)
        
        row.labelName:SetText(zoneDef.name)
        row.widget:Show(true)

        if zoneState then
            local stateText = GetStateName(zoneState.stateId)
            local timeText = GetTimeText(zoneState.remainTime)
            local col = GetStateColor(zoneState.stateId)
            
            if zoneState.remainTime > 0 then
                row.labelStatus:SetText(stateText .. " (" .. timeText .. ")")
            else
                row.labelStatus:SetText(stateText)
            end
            
            row.labelStatus:SetTextColor(col[1], col[2], col[3], col[4])
        else
            row.labelStatus:SetText("Unknown")
            row.labelStatus:SetTextColor(0.5, 0.5, 0.5, 1)
        end
    end
    
    -- Hide unused rows
    for i = #zoneList + 1, #row_widgets do
        row_widgets[i].widget:Show(false)
    end
end

local function SwitchTab(tabName)
    current_tab = tabName
    UpdateTimers()
end

local function ToggleMinimize()
    is_minimized = not is_minimized
    if is_minimized then
        window:SetExtent(WINDOW_WIDTH, 60)
        content_frame:Show(false)
    else
        window:SetExtent(WINDOW_WIDTH, 200)
        content_frame:Show(true)
        UpdateTimers()
    end
end

------------------------------------------------------
-- STARTUP
------------------------------------------------------
function war_timers.OnLoad()
    -- Create Window
    window = api.Interface:CreateWindow("WarTimersWin", "War Status", WINDOW_WIDTH, 200)
    window:AddAnchor("CENTER", "UIParent", 0, 0)
    window:EnableDrag(true)

    -- Background
    local bg = window:CreateNinePartDrawable(TEXTURE_PATH.HUD, "background")
    bg:SetTextureInfo("bg_quest")
    bg:SetColor(BG_COLOR[1], BG_COLOR[2], BG_COLOR[3], BG_COLOR[4])
    bg:AddAnchor("TOPLEFT", window, 0, 0)
    bg:AddAnchor("BOTTOMRIGHT", window, 0, 0)

    -- Tabs
    local btnNuia = window:CreateChildWidget("button", "btnNuia", 0, true)
    btnNuia:SetText("Nuia")
    btnNuia:SetExtent((WINDOW_WIDTH/2) - 10, 25)
    btnNuia:AddAnchor("TOPLEFT", window, 5, 30)
    api.Interface:ApplyButtonSkin(btnNuia, BUTTON_BASIC.DEFAULT)
    
    local btnHara = window:CreateChildWidget("button", "btnHara", 0, true)
    btnHara:SetText("Haranya")
    btnHara:SetExtent((WINDOW_WIDTH/2) - 10, 25)
    btnHara:AddAnchor("TOPLEFT", window, (WINDOW_WIDTH/2) + 5, 30)
    api.Interface:ApplyButtonSkin(btnHara, BUTTON_BASIC.DEFAULT)

    -- Min/Max Button
    local btnMin = window:CreateChildWidget("button", "btnMin", 0, true)
    btnMin:SetText("-")
    btnMin:SetExtent(20, 20)
    btnMin:AddAnchor("TOPRIGHT", window, -5, 5)
    api.Interface:ApplyButtonSkin(btnMin, BUTTON_BASIC.DEFAULT)

    -- Content Area
    content_frame = window:CreateChildWidget("emptywidget", "content", 0, true)
    content_frame:AddAnchor("TOPLEFT", window, 0, 60)
    content_frame:AddAnchor("BOTTOMRIGHT", window, 0, 0)

    -- Click Events
    btnNuia:SetHandler("OnClick", function() SwitchTab("NUIA") end)
    btnHara:SetHandler("OnClick", function() SwitchTab("HARANYA") end)
    btnMin:SetHandler("OnClick", ToggleMinimize)

    -- Update Loop (Every 1 second)
    api.On("UPDATE", function(dt)
        local now = api.Time:GetUiTime()
        if now - last_update_time > 1000 then
            UpdateTimers()
            last_update_time = now
        end
    end)

    window:Show(true)
    UpdateTimers()
end

function war_timers.OnUnload()
    if window then window:Show(false) end
end

return war_timers